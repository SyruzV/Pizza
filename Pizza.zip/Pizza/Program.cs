﻿
    class Program
    {

        static void Main(string[] args)
        {
            int canth, cantt;

            const float precioh = 5.60f,preciop=2.50f,precior=2.30f;
            double totalapagar;

            Console.Write("Ingrese la cantidad de pizzas: ");
            canth = Int32.Parse(Console.ReadLine());
            Console.Write("Tamaño de las Pizzas: ");
            cantt = Int32.Parse(Console.ReadLine());

            totalapagar=(canth*precioh)+(cantt*preciop);

            Console.WriteLine("El total a pagar es: " +totalapagar);

        }
    }